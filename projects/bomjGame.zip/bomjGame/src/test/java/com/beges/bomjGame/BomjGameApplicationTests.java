package com.beges.bomjGame;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BomjGameApplicationTests {

	@Test
	void contextLoads() {
	}

}
