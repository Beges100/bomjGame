package com.beges.bomjGame.service.abstracts.repository;

public interface ReadOnlyService<E, K> {
}
