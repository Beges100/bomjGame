package com.beges.bomjGame.service.abstracts.repository;

public interface ReadWriteService<E, K> extends ReadOnlyService<E, K> {
}
